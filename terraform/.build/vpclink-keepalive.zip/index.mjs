// Keeps the API Gateway VPC link out of its 60-day INACTIVE transition.
// Throwing on a non-2xx makes a broken ingress visible as a Lambda error
// metric, which is worth having now that the ALB health check is gone.
export const handler = async () => {
  const url = process.env.KEEPALIVE_URL;
  const startedAt = Date.now();
  const res = await fetch(url, { signal: AbortSignal.timeout(15_000) });
  const result = { url, status: res.status, elapsedMs: Date.now() - startedAt };
  console.log(JSON.stringify(result));
  if (!res.ok) throw new Error(`keepalive: ${url} returned ${res.status}`);
  return result;
};
